use CRI Packed File Maker to extract FILEDATA.CPK,

place MagicCodeRenamer.exe and database.txt in the 
same folder as the extracted files, this program will 
detect the FileHeader based on database.txt and adds 
an extension on it.